-- --------------------------------------------------------
-- 호스트:                          k7c105.p.ssafy.io
-- 서버 버전:                        10.3.34-MariaDB-0ubuntu0.20.04.1 - Ubuntu 20.04
-- 서버 OS:                        debian-linux-gnu
-- HeidiSQL 버전:                  11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- lyra 데이터베이스 구조 내보내기
CREATE DATABASE IF NOT EXISTS `lyra` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `lyra`;

-- 테이블 lyra.charge 구조 내보내기
CREATE TABLE IF NOT EXISTS `charge` (
  `charge_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ca` varchar(255) NOT NULL,
  `coin` bigint(20) NOT NULL,
  `time` datetime(6) DEFAULT NULL,
  `wallet_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`charge_id`),
  KEY `FK2kjmhlfjuyxxr61lmb9ve54sc` (`wallet_id`),
  CONSTRAINT `FK2kjmhlfjuyxxr61lmb9ve54sc` FOREIGN KEY (`wallet_id`) REFERENCES `wallet` (`wallet_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 lyra.comment 구조 내보내기
CREATE TABLE IF NOT EXISTS `comment` (
  `comment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) NOT NULL,
  `time` datetime(6) DEFAULT NULL,
  `pheed_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `FK1j9g0d8g5ok2eaod75fa36tuh` (`pheed_id`),
  KEY `FK8kcum44fvpupyw6f5baccx25c` (`user_id`),
  CONSTRAINT `FK1j9g0d8g5ok2eaod75fa36tuh` FOREIGN KEY (`pheed_id`) REFERENCES `pheed` (`pheed_id`),
  CONSTRAINT `FK8kcum44fvpupyw6f5baccx25c` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 lyra.follow 구조 내보내기
CREATE TABLE IF NOT EXISTS `follow` (
  `follow_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `follower_id` bigint(20) DEFAULT NULL,
  `following_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`follow_id`),
  KEY `FKmow2qk674plvwyb4wqln37svv` (`follower_id`),
  KEY `FKqme6uru2g9wx9iysttk542esm` (`following_id`),
  CONSTRAINT `FKmow2qk674plvwyb4wqln37svv` FOREIGN KEY (`follower_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FKqme6uru2g9wx9iysttk542esm` FOREIGN KEY (`following_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 lyra.notice 구조 내보내기
CREATE TABLE IF NOT EXISTS `notice` (
  `notice_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `written_times` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`notice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 lyra.participant 구조 내보내기
CREATE TABLE IF NOT EXISTS `participant` (
  `participant_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `is_in` bit(1) DEFAULT NULL,
  `pheed_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`participant_id`),
  KEY `FKc926krdyvmjkjhwqo6ncnug87` (`pheed_id`),
  KEY `FKj2ywtc5meno2ouhf5pcq9rsbh` (`user_id`),
  CONSTRAINT `FKc926krdyvmjkjhwqo6ncnug87` FOREIGN KEY (`pheed_id`) REFERENCES `pheed` (`pheed_id`),
  CONSTRAINT `FKj2ywtc5meno2ouhf5pcq9rsbh` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 lyra.pheed 구조 내보내기
CREATE TABLE IF NOT EXISTS `pheed` (
  `pheed_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `latitude` decimal(19,2) NOT NULL,
  `location` varchar(255) NOT NULL,
  `longitude` decimal(19,2) NOT NULL,
  `region_code` varchar(255) NOT NULL,
  `start_time` datetime(6) NOT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `time` datetime(6) DEFAULT NULL,
  `title` varchar(30) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `wish_count` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`pheed_id`),
  KEY `FKcq5tbxx1aeij11sgcud62ybch` (`user_id`),
  CONSTRAINT `FKcq5tbxx1aeij11sgcud62ybch` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 lyra.pheed_img 구조 내보내기
CREATE TABLE IF NOT EXISTS `pheed_img` (
  `pheed_img_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mime` varchar(255) DEFAULT NULL,
  `path` varchar(500) DEFAULT NULL,
  `pheed_id` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pheed_img_id`),
  KEY `FKdlcxh5gjm6c2iql9e6ssq7fkx` (`pheed_id`),
  CONSTRAINT `FKdlcxh5gjm6c2iql9e6ssq7fkx` FOREIGN KEY (`pheed_id`) REFERENCES `pheed` (`pheed_id`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 lyra.pheed_tag 구조 내보내기
CREATE TABLE IF NOT EXISTS `pheed_tag` (
  `pheed_tag_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `pheed_id` bigint(20) DEFAULT NULL,
  `tag_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`pheed_tag_id`),
  KEY `FK16rsmasf9ng2pmxc8i6syp4u0` (`pheed_id`),
  KEY `FKdrlsloeru275rkmrshguk1s7c` (`tag_id`),
  CONSTRAINT `FK16rsmasf9ng2pmxc8i6syp4u0` FOREIGN KEY (`pheed_id`) REFERENCES `pheed` (`pheed_id`),
  CONSTRAINT `FKdrlsloeru275rkmrshguk1s7c` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 lyra.room 구조 내보내기
CREATE TABLE IF NOT EXISTS `room` (
  `room_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pheed_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`room_id`),
  KEY `FK1gy59fybkr2ri4u2t2qt5pqub` (`pheed_id`),
  CONSTRAINT `FK1gy59fybkr2ri4u2t2qt5pqub` FOREIGN KEY (`pheed_id`) REFERENCES `pheed` (`pheed_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 lyra.shorts 구조 내보내기
CREATE TABLE IF NOT EXISTS `shorts` (
  `shorts_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `path` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `region_code` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `time` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`shorts_id`),
  KEY `FKfo5bbkeyrke46k6hpdinkefj7` (`user_id`),
  CONSTRAINT `FKfo5bbkeyrke46k6hpdinkefj7` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8mb4;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 lyra.SPRING_SESSION 구조 내보내기
CREATE TABLE IF NOT EXISTS `SPRING_SESSION` (
  `PRIMARY_ID` char(36) NOT NULL,
  `SESSION_ID` char(36) NOT NULL,
  `CREATION_TIME` bigint(20) NOT NULL,
  `LAST_ACCESS_TIME` bigint(20) NOT NULL,
  `MAX_INACTIVE_INTERVAL` int(11) NOT NULL,
  `EXPIRY_TIME` bigint(20) NOT NULL,
  `PRINCIPAL_NAME` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`PRIMARY_ID`),
  UNIQUE KEY `SPRING_SESSION_IX1` (`SESSION_ID`),
  KEY `SPRING_SESSION_IX2` (`EXPIRY_TIME`),
  KEY `SPRING_SESSION_IX3` (`PRINCIPAL_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 lyra.SPRING_SESSION_ATTRIBUTES 구조 내보내기
CREATE TABLE IF NOT EXISTS `SPRING_SESSION_ATTRIBUTES` (
  `SESSION_PRIMARY_ID` char(36) NOT NULL,
  `ATTRIBUTE_NAME` varchar(200) NOT NULL,
  `ATTRIBUTE_BYTES` blob NOT NULL,
  PRIMARY KEY (`SESSION_PRIMARY_ID`,`ATTRIBUTE_NAME`),
  CONSTRAINT `SPRING_SESSION_ATTRIBUTES_FK` FOREIGN KEY (`SESSION_PRIMARY_ID`) REFERENCES `SPRING_SESSION` (`PRIMARY_ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 lyra.support 구조 내보내기
CREATE TABLE IF NOT EXISTS `support` (
  `support_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ca` varchar(255) NOT NULL,
  `coin` bigint(20) NOT NULL,
  `content` varchar(255) DEFAULT NULL,
  `time` datetime(6) DEFAULT NULL,
  `busker_id` bigint(20) DEFAULT NULL,
  `pheed_id` bigint(20) DEFAULT NULL,
  `supporter_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`support_id`),
  KEY `FKdwi4fnm6og4j6nc3en3srbrhe` (`busker_id`),
  KEY `FKsbtr6hpdxeyudut4r9gi0w58q` (`pheed_id`),
  KEY `FKhdauwnnkrl38jjoitv6yu5va6` (`supporter_id`),
  CONSTRAINT `FKdwi4fnm6og4j6nc3en3srbrhe` FOREIGN KEY (`busker_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FKhdauwnnkrl38jjoitv6yu5va6` FOREIGN KEY (`supporter_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FKsbtr6hpdxeyudut4r9gi0w58q` FOREIGN KEY (`pheed_id`) REFERENCES `pheed` (`pheed_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 lyra.tag 구조 내보내기
CREATE TABLE IF NOT EXISTS `tag` (
  `tag_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 lyra.talk 구조 내보내기
CREATE TABLE IF NOT EXISTS `talk` (
  `talk_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `is_read` bit(1) DEFAULT NULL,
  `written_times` datetime(6) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`talk_id`),
  KEY `FKcuvdh01cnotcukbyvw910jo3g` (`user_id`),
  CONSTRAINT `FKcuvdh01cnotcukbyvw910jo3g` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 lyra.user 구조 내보내기
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `account` varchar(255) DEFAULT NULL,
  `bank` varchar(10) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `introduction` varchar(255) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `nickname` varchar(10) DEFAULT NULL,
  `refresh_token` varchar(255) DEFAULT NULL,
  `latitude` decimal(19,2) DEFAULT NULL,
  `longitude` decimal(19,2) DEFAULT NULL,
  `holder` varchar(255) DEFAULT NULL,
  `follower_count` bigint(20) DEFAULT NULL,
  `following_count` bigint(20) DEFAULT NULL,
  `region_code` varchar(255) DEFAULT NULL,
  `region_name` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `fcm` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 lyra.user_roles 구조 내보내기
CREATE TABLE IF NOT EXISTS `user_roles` (
  `user_user_id` bigint(20) NOT NULL,
  `roles` varchar(255) DEFAULT NULL,
  KEY `FKkv46dn3qakjvsk7ra33nd5sns` (`user_user_id`),
  CONSTRAINT `FKkv46dn3qakjvsk7ra33nd5sns` FOREIGN KEY (`user_user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 lyra.wallet 구조 내보내기
CREATE TABLE IF NOT EXISTS `wallet` (
  `wallet_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`wallet_id`),
  UNIQUE KEY `UK_hgee4p1hiwadqinr0avxlq4eb` (`user_id`),
  CONSTRAINT `FKbs4ogwiknsup4rpw8d47qw9dx` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 lyra.wish 구조 내보내기
CREATE TABLE IF NOT EXISTS `wish` (
  `wish_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pheed_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`wish_id`),
  KEY `FK68133qrpp991xr6d7ccfumn4u` (`pheed_id`),
  KEY `FKkqi4lso34o5xjkhiw71uadwvu` (`user_id`),
  CONSTRAINT `FK68133qrpp991xr6d7ccfumn4u` FOREIGN KEY (`pheed_id`) REFERENCES `pheed` (`pheed_id`),
  CONSTRAINT `FKkqi4lso34o5xjkhiw71uadwvu` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4;

-- 내보낼 데이터가 선택되어 있지 않습니다.

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
